# The-Enclave-High-DPI
The Enclave, but with big pretty pictures.
